class arme {
    constructor(nom, degat, img) {
        this.nom = nom;
        this.degat = degat;
        this.image = img;
    }




}