

class player {
    constructor(nom, img, statutActif) {
        this.nom = nom;
        this.image = img;
        this.statutActif = statutActif;
        this.pointDeVie = 100;
        this.coord = {x:0,y:0}
    }


}

